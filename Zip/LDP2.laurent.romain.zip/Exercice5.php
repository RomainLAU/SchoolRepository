<?php

$tab = ['Le Guide du voyageur galactique',
	'Le Dernier Restaurant avant la fin du monde',
	'La Vie , l\'Univers et le Reste',
	'Salut et encore merci pour le poison',
	'Globalment inoffensive'
];

foreach ($tab as $keys => $values) {
	echo("$values <br>");
}

?>