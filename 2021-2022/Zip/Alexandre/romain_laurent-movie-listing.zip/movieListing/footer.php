<footer id="footer">
    <p>Movie Lister &copy;</p> 
</footer>