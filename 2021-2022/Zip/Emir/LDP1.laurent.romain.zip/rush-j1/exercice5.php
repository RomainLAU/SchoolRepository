<?php

function concat($sentence1, $sentence2) {
    echo("$sentence1 $sentence2");
}

concat("Hello", "World");

?>