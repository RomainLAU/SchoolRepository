<?php

function somme($number1, $number2) {
    return $number1 + $number2;
}

var_dump(somme(5,8));

?>