<?php
$name = "Romain";
echo("Hello $name");
?>