<?php

function oddOrEven($data) {
    if ($data%2 == 0) {
        echo('Even');
    } else {
        echo('Odd');
    }
}

oddOrEven(19);

?>