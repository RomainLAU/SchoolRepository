<?php
function myEcho($data) {
    echo("$data<br>");
}

myEcho("I");
myEcho("CALL");
myEcho("THE");
myEcho("CYBER");
myEcho("POLICE");

?>