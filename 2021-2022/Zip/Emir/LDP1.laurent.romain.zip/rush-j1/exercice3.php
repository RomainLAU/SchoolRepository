<?php
function myHelloWorld() {
    echo('Hello World');
}

myHelloWorld();
?>