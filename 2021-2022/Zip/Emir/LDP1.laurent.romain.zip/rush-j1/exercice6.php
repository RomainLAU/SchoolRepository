<?php

function concat2($sentence1, $sentence2) {
    echo($sentence1 . ' ' . $sentence2);

}

concat2("Hello", "World");

?>